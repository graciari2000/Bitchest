<template>
    <div :class="$style.login">
        <div :class="$style.loginChild" />
        <img :class="$style.loginItem" alt="" />
        <div :class="$style.loginParent">
            <b :class="$style.login2">Login</b>
            <div :class="$style.howToI">How to i get started lorem ipsum dolor at?</div>
            <div :class="$style.dontHaveAn">Don’t have an account? Register here!</div>
            <div :class="$style.rectangleParent">
                <div :class="$style.groupChild" />
                <div :class="$style.password">Password</div>
                <img :class="$style.frameIcon" alt="" />
            </div>
            <div :class="$style.rectangleGroup">
                <div :class="$style.groupChild" />
                <div :class="$style.password">Username</div>
                <img :class="$style.frameIcon" alt="" />
            </div>
            <div :class="$style.rectangleContainer">
                <div :class="$style.groupInner" />
                <b :class="$style.loginNow">Login Now</b>
            </div>
        </div>
        <div :class="$style.groupDiv">
            <div :class="$style.rectangleDiv" />
            <img :class="$style.groupIcon" alt="" />
        </div>
        <div :class="$style.loginRectangleParent">
            <div :class="$style.rectangleDiv" />
            <img :class="$style.groupChild2" alt="" />
        </div>
    </div>
</template>
<style module>
.login {
    width: 100%;
    height: 768px;
    position: relative;
    border-radius: 24px;
    background-color: #fff;
    overflow: hidden;
    text-align: left;
    font-size: 12px;
    color: #525252;
    font-family: Poppins;
}

.loginChild {
    position: absolute;
    top: 0px;
    right: 0px;
    background: linear-gradient(217.64deg, #9181f4, #5038ed);
    width: 683px;
    height: 768px;
}

.loginItem {
    position: absolute;
    top: 0px;
    right: 0px;
    width: 683px;
    height: 768px;
    object-fit: cover;
}

.loginParent {
    position: absolute;
    top: 238px;
    left: 138px;
    width: 364px;
    height: 325px;
}

.login2 {
    position: absolute;
    top: 0px;
    left: 135px;
    font-size: 30px;
    text-transform: uppercase;
    color: #000;
}

.howToI {
    position: absolute;
    top: 31px;
    left: 14px;
    font-size: 16px;
}

.dontHaveAn {
    position: absolute;
    top: 301px;
    left: 38px;
    font-size: 16px;
}

.rectangleParent {
    position: absolute;
    top: 149px;
    left: 0px;
    width: 364px;
    height: 52px;
    color: #1c1c1c;
}

.groupChild {
    position: absolute;
    top: 0px;
    left: 0px;
    border-radius: 16px;
    background-color: rgba(240, 237, 255, 0.8);
    width: 364px;
    height: 52px;
}

.password {
    position: absolute;
    top: 17px;
    left: 48px;
}

.frameIcon {
    position: absolute;
    top: 14px;
    left: 18px;
    width: 24px;
    height: 24px;
}

.rectangleGroup {
    position: absolute;
    top: 79px;
    left: 0px;
    width: 364px;
    height: 52px;
    color: #1c1c1c;
}

.rectangleContainer {
    position: absolute;
    top: 225px;
    left: 120px;
    width: 124px;
    height: 52px;
    color: #fff;
}

.groupInner {
    position: absolute;
    top: 0px;
    left: 0px;
    box-shadow: 0px 8px 21px rgba(0, 0, 0, 0.16);
    border-radius: 16px;
    background: linear-gradient(99.78deg, #00ff19, rgba(0, 255, 25, 0.75));
    width: 124px;
    height: 52px;
}

.loginNow {
    position: absolute;
    top: 17px;
    left: 30px;
}

.groupDiv {
    position: absolute;
    top: 610px;
    left: 186px;
    width: 125px;
    height: 52px;
}

.rectangleDiv {
    position: absolute;
    top: 0px;
    left: 0px;
    border-radius: 16px;
    border: 1px solid #f0edff;
    box-sizing: border-box;
    width: 125px;
    height: 52px;
}

.groupIcon {
    position: absolute;
    top: 11px;
    left: 37.77px;
    width: 30px;
    height: 30px;
    object-fit: cover;
}

.loginRectangleParent {
    position: absolute;
    top: 610px;
    left: 346px;
    width: 125px;
    height: 52px;
}

.groupChild2 {
    position: absolute;
    top: 11px;
    left: 47px;
    width: 30px;
    height: 30px;
    object-fit: cover;
}
</style>