<script setup lang="ts">
import { ref } from 'vue'

const sidebarCollapsed = ref(false)

const menuItems = [
    { name: 'Dashboard', active: true },
    { name: 'Wallet', active: false },
    { name: 'Messages', active: false, badge: true },
    { name: 'Trade', active: false },
    { name: 'Account Setting', active: false },
    { name: 'Clients', active: false },
]

const statistics = [
    { value: '19678', symbol: 'BTC', change: '+12.5%' },
    { value: '23.234', label: 'ETH', sublabel: 'Transactions' },
    { value: '380.234', label: 'LTC', sublabel: 'Funds', positive: true },
]

const notifications = [
    {
        name: 'Clifford Hale',
        message: 'Hello! I have a problem with my payment methods..',
        time: '2 hours ago',
        type: 'message',
    },
    {
        name: 'Lottie Marsh',
        message: 'New transaction',
        amount: '+380.234 LTC',
        time: '3 hours ago',
        type: 'transaction',
        positive: true,
        initial: 'L',
    },
    {
        name: 'BTC',
        message: 'Bitcoin is up by 5 points today.',
        change: '+39.69%',
        time: '3 hours ago',
        type: 'news',
        initial: 'B',
    },
    {
        name: 'Danny Jacobs',
        message: "Let's talk when we have time.",
        time: '2 hours ago',
        type: 'message',
    },
]

const history = [
    { name: 'Danny Jacobs atau Joko Boyer Utomo', amount: '+0.025', date: '08/26/2018', positive: true },
    { name: 'Clifford hale', amount: '-5.23%', date: '08/26/2018', positive: false },
    { name: 'Buat beli susu anak', amount: '-5.23%', date: '08/26/2018', positive: false, highlighted: true },
    { name: 'Langganan odobe CC', amount: '-5.23%', date: '08/26/2018', positive: false },
    { name: 'Hasil mining 3 mingguu', amount: '+0.025', date: '08/26/2018', positive: true },
]

const trends = [
    { symbol: 'BTC', value: '7.356,67', change: '-5.23%', positive: false },
    { symbol: 'ETH', value: '465,22', change: '+132%', positive: true },
    { symbol: 'LTC', value: '104,23', change: '+75.69%', positive: true },
]
</script>

<template>
    <div
        class="min-h-screen bg-background text-text dark:text-text-800 dark:bg-background-950 transition-colors duration-300">
        <!-- Sidebar -->
        <aside :class="[
            'fixed left-0 top-0 h-screen z-40 transition-all duration-300 w-64',
            'bg-background-100 dark:bg-gradient-to-b dark:from-background-950 dark:via-background-900 dark:to-background-950',
            'border-r border-text-200 dark:border-background-800',
        ]">
            <nav class="pt-16 px-8 space-y-8">
                <a v-for="(item, index) in menuItems" :key="index" href="#" :class="[
                    'flex items-center gap-4 text-sm font-medium px-4 py-3 rounded-lg transition-colors relative group',
                    item.active
                        ? 'text-primary dark:text-primary-500 bg-primary-50 dark:bg-primary-950'
                        : 'text-text-600 dark:text-neutral-text hover:text-primary dark:hover:text-primary-500',
                ]">
                    <div class="w-5 h-5 rounded bg-primary-200 dark:bg-primary-900"></div>
                    <span>{{ item.name }}</span>
                    <div v-if="item.badge"
                        class="absolute right-4 w-2 h-2 rounded-full bg-secondary-500 dark:bg-danger"></div>
                </a>
            </nav>
        </aside>

        <!-- Main Content -->
        <div class="ml-64 min-h-screen">
            <!-- Header -->
            <header
                class="px-8 py-6 border-b border-text-200 dark:border-background-800 bg-white dark:bg-background-900">
                <div class="flex items-center justify-between">
                    <div>
                        <h1 class="text-3xl font-bold text-text dark:text-text-800">Dashboard</h1>
                        <p class="text-text-600 dark:text-neutral-text text-sm mt-1">Welcome, Admin!</p>
                    </div>

                    <div class="flex items-center gap-6">
                        <button class="p-2 hover:bg-text-100 dark:hover:bg-background-800 rounded-lg transition-colors">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <circle cx="9" cy="9" r="7" stroke="currentColor" stroke-width="1.5" />
                                <path d="M13 13L16 16" stroke="currentColor" stroke-width="1.5"
                                    stroke-linecap="round" />
                            </svg>
                        </button>

                        <button class="p-2 hover:bg-text-100 dark:hover:bg-background-800 rounded-lg transition-colors">
                            <div class="grid grid-cols-3 gap-1 w-5 h-5">
                                <div class="w-1 h-1 rounded-full bg-text-600 dark:bg-text-300"></div>
                                <div class="w-1 h-1 rounded-full bg-text-600 dark:bg-text-300"></div>
                                <div class="w-1 h-1 rounded-full bg-text-600 dark:bg-text-300"></div>
                                <div class="w-1 h-1 rounded-full bg-text-600 dark:bg-text-300"></div>
                                <div class="w-1 h-1 rounded-full bg-text-600 dark:bg-text-300"></div>
                                <div class="w-1 h-1 rounded-full bg-text-600 dark:bg-text-300"></div>
                                <div class="w-1 h-1 rounded-full bg-text-600 dark:bg-text-300"></div>
                                <div class="w-1 h-1 rounded-full bg-text-600 dark:bg-text-300"></div>
                                <div class="w-1 h-1 rounded-full bg-text-600 dark:bg-text-300"></div>
                            </div>
                        </button>

                        <div
                            class="px-3 py-1.5 rounded-full flex items-center gap-2 bg-secondary-500 dark:bg-danger text-white text-xs font-medium">
                            <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor">
                                <path
                                    d="M6 1C5.44772 1 5 1.44772 5 2V3H2C1.44772 3 1 3.44772 1 4V10C1 10.5523 1.44772 11 2 11H10C10.5523 11 11 10.5523 11 10V4C11 3.44772 10.5523 3 10 3H7V2C7 1.44772 6.55228 1 6 1Z" />
                            </svg>
                            15
                        </div>

                        <div class="flex items-center gap-3">
                            <img src="https://api.builder.io/api/v1/image/assets/TEMP/6878da621cc6fbc5afde884e8db308ccb609ab42"
                                alt="User" class="w-8 h-8 rounded" />
                            <div class="flex items-center gap-2">
                                <span class="text-sm font-medium text-text dark:text-text-800">Pixelz Warrios</span>
                                <svg width="4" height="6" viewBox="0 0 4 6" fill="none">
                                    <path d="M0 0L2 3L4 0" stroke="currentColor" stroke-width="1" />
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Content -->
            <main class="p-8">
                <!-- Statistics Section -->
                <div class="mb-8">
                    <h2
                        class="text-xs font-semibold text-text-600 dark:text-neutral-muted uppercase tracking-widest mb-4">
                        Statistics
                    </h2>

                    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <!-- Primary Card -->
                        <div
                            class="rounded-xl bg-primary dark:bg-primary-500 text-white p-6 relative overflow-hidden group cursor-pointer hover:shadow-lg transition-shadow">
                            <div class="absolute inset-0 opacity-20 group-hover:opacity-30 transition-opacity"
                                style="background: linear-gradient(135deg, transparent 0%, rgba(255,255,255,0.1) 100%)">
                            </div>
                            <div class="relative">
                                <div class="text-2xl font-bold mb-1">19678</div>
                                <div class="text-xs font-medium">+12.5%</div>
                            </div>
                        </div>

                        <!-- Stat Card 2 -->
                        <div
                            class="rounded-xl bg-white dark:bg-background-800 border border-text-200 dark:border-background-700 p-6">
                            <div class="text-xl font-semibold text-text dark:text-text-800 mb-1">23.234</div>
                            <div class="text-xs text-text-600 dark:text-neutral-text">Transactions</div>
                        </div>

                        <!-- Stat Card 3 -->
                        <div
                            class="rounded-xl bg-white dark:bg-background-800 border border-text-200 dark:border-background-700 p-6">
                            <div class="text-xl font-semibold text-accent dark:text-accent-500 mb-1">380.234</div>
                            <div class="text-xs text-text-600 dark:text-neutral-text">Funds</div>
                        </div>

                        <!-- Add Currency -->
                        <div
                            class="rounded-xl border-2 border-dashed border-text-300 dark:border-background-700 p-6 flex items-center justify-center cursor-pointer hover:bg-text-50 dark:hover:bg-background-800 transition-colors">
                            <div class="text-xs font-bold text-text-400 dark:text-text-600">+ Add Currency</div>
                        </div>
                    </div>
                </div>

                <!-- Graph and Layout -->
                <div class="grid grid-cols-1 xl:grid-cols-3 gap-6">
                    <!-- Left Column: Graph -->
                    <div class="xl:col-span-2 space-y-6">
                        <!-- Chart Card -->
                        <div
                            class="rounded-xl bg-white dark:bg-background-800 p-6 h-96 flex items-center justify-center border border-text-200 dark:border-background-700">
                            <div class="text-center text-text-600 dark:text-neutral-text">
                                <div class="text-sm mb-2">📈 Chart Area</div>
                                <div class="text-xs">Your trading chart will appear here</div>
                            </div>
                        </div>

                        <!-- Trends -->
                        <div>
                            <h3
                                class="text-xs font-semibold text-text-600 dark:text-neutral-muted uppercase tracking-widest mb-4">
                                Trend
                            </h3>

                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div v-for="trend in trends" :key="trend.symbol"
                                    class="rounded-xl bg-white dark:bg-background-800 border border-text-200 dark:border-background-700 p-4">
                                    <div class="flex items-center justify-between mb-3">
                                        <div class="text-sm font-bold text-text dark:text-text-800">{{ trend.symbol }}
                                        </div>
                                        <div
                                            :class="['text-xs font-medium', trend.positive ? 'text-accent' : 'text-secondary-500']">
                                            {{ trend.change }}
                                        </div>
                                    </div>
                                    <div class="text-lg font-semibold text-text dark:text-text-800">{{ trend.value }}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- History -->
                        <div>
                            <div class="flex items-center justify-between mb-4">
                                <h3
                                    class="text-xs font-semibold text-text-600 dark:text-neutral-muted uppercase tracking-widest">
                                    History
                                </h3>
                                <a href="#" class="text-xs text-primary dark:text-primary-500 hover:underline">See
                                    All</a>
                            </div>

                            <div class="space-y-2">
                                <div v-for="(item, index) in history" :key="index" :class="[
                                    'flex items-center justify-between p-4 rounded-lg transition-colors',
                                    item.highlighted
                                        ? 'bg-primary-50 dark:bg-primary-950 border border-primary-200 dark:border-primary-900'
                                        : 'hover:bg-text-50 dark:hover:bg-background-700',
                                ]">
                                    <div>
                                        <div class="text-sm font-medium text-text dark:text-text-800">{{ item.name }}
                                        </div>
                                    </div>
                                    <div class="flex items-center gap-6">
                                        <div
                                            :class="['text-xs font-medium', item.positive ? 'text-accent' : 'text-secondary-500']">
                                            {{ item.amount }}
                                        </div>
                                        <div class="text-xs text-text-600 dark:text-neutral-text w-20 text-right">{{
                                            item.date }}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Right Column: Notifications -->
                    <div class="xl:col-span-1">
                        <div
                            class="rounded-xl bg-white dark:bg-background-800 border border-text-200 dark:border-background-700 p-6">
                            <h3
                                class="text-xs font-semibold text-text-600 dark:text-neutral-muted uppercase tracking-widest mb-6">
                                Notifications
                            </h3>

                            <div class="space-y-4">
                                <div v-for="(notif, index) in notifications" :key="index"
                                    class="pb-4 border-b border-text-100 dark:border-background-700 last:border-b-0">
                                    <div class="flex items-start gap-3">
                                        <div v-if="notif.initial" :class="[
                                            'w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white',
                                            notif.type === 'transaction'
                                                ? 'bg-gradient-to-br from-accent to-accent-600'
                                                : 'bg-gradient-to-br from-secondary to-secondary-600',
                                        ]">
                                            {{ notif.initial }}
                                        </div>
                                        <div v-else
                                            class="w-8 h-8 rounded-full bg-text-200 dark:bg-background-700 flex-shrink-0">
                                        </div>

                                        <div class="flex-1 min-w-0">
                                            <h4 class="text-xs font-bold text-text dark:text-text-800">{{ notif.name }}
                                            </h4>
                                            <p class="text-xs text-text-600 dark:text-neutral-text mt-1">{{
                                                notif.message }}</p>
                                            <div v-if="notif.amount" class="text-xs text-accent mt-1 font-medium">{{
                                                notif.amount }}</div>
                                            <div v-if="notif.change" class="text-xs text-accent mt-1 font-medium">{{
                                                notif.change }}</div>
                                            <div class="text-xs text-text-500 dark:text-text-500 mt-2">{{ notif.time }}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <a href="#"
                                class="text-xs text-primary dark:text-primary-500 hover:underline block text-center mt-4">See
                                All</a>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
</template>
