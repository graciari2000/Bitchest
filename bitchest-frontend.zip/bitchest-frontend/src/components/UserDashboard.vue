<template>
  <div :class="$style.clientDashboardDark">
    <div :class="$style.history">
      <div :class="$style.sectionTitle">
        <div :class="$style.clientDashboardDarkHistory">History</div>
        <div :class="$style.seeAll">See All</div>
      </div>
      <div :class="$style.list1">
        <img :class="$style.list1Child" alt="" />
        <div :class="$style.akhirnyaJokoBayarContainer">
          <span :class="$style.akhirnyaJokoBayar">Akhirnya Joko bayar Utan</span>g
        </div>
        <div :class="$style.div">08/26/2018</div>
        <div :class="$style.clientDashboardDarkDiv">+0.025</div>
      </div>
      <div :class="$style.list2">
        <img :class="$style.list2Child" alt="" />
        <div :class="$style.cicilanMobil">Cicilan mobil</div>
        <div :class="$style.div2">08/26/2018</div>
        <div :class="$style.div3">-5.23%</div>
      </div>
      <div :class="$style.list4">
        <div :class="$style.rectangleParent">
          <div :class="$style.groupChild" />
          <img :class="$style.shapeIcon" alt="" />
        </div>
        <div :class="$style.cicilanMobil">Langganan odobe CC</div>
        <div :class="$style.div2">08/26/2018</div>
        <div :class="$style.div3">-5.23%</div>
      </div>
      <div :class="$style.list5">
        <img :class="$style.list5Child" alt="" />
        <div :class="$style.cicilanMobil">Hasil mining 3 mingguu</div>
        <div :class="$style.div2">08/26/2018</div>
        <div :class="$style.div7">+0.025</div>
      </div>
      <div :class="$style.list3Popup">
        <div :class="$style.list3PopupChild" />
        <div :class="$style.group35Copy5">
          <img :class="$style.group35Copy5Child" alt="" />
          <div :class="$style.buatBeliSusu">Buat beli susu anak</div>
          <div :class="$style.div8">08/26/2018</div>
          <div :class="$style.div9">-5.23%</div>
        </div>
      </div>
    </div>
    <div :class="$style.trend">
      <div :class="$style.clientDashboardDarkTrend">Trend</div>
      <div :class="$style.div10">
        <div :class="$style.base" />
        <div :class="$style.btcUsd">
          <b :class="$style.btc">BTC</b>
          <b :class="$style.usd">USD</b>
          <img :class="$style.icnIcon" alt="" />
        </div>
        <div :class="$style.glow" />
        <div :class="$style.div11">7.356,67</div>
        <div :class="$style.div12">
          <div :class="$style.div13">-5.23%</div>
          <img :class="$style.downArrowIcon" alt="" />
        </div>
      </div>
      <div :class="$style.div14">
        <div :class="$style.base" />
        <div :class="$style.ethUsd">
          <b :class="$style.btc">ETH</b>
          <b :class="$style.clientDashboardDarkUsd">USD</b>
          <img :class="$style.clientDashboardDarkIcnIcon" alt="" />
        </div>
        <div :class="$style.clientDashboardDarkGlow" />
        <img :class="$style.path2Icon" alt="" />
        <div :class="$style.div11">465,22</div>
        <div :class="$style.div16">
          <div :class="$style.div17">+132%</div>
          <img :class="$style.upArrowIcon" alt="" />
        </div>
      </div>
      <div :class="$style.div18">
        <div :class="$style.base" />
        <div :class="$style.clientDashboardDarkEthUsd">
          <b :class="$style.btc">LTC</b>
          <b :class="$style.usd2">USD</b>
          <img :class="$style.icnIcon2" alt="" />
        </div>
        <div :class="$style.glow2" />
        <img :class="$style.clientDashboardDarkPath2Icon" alt="" />
        <div :class="$style.div11">104,23</div>
        <div :class="$style.div20">
          <div :class="$style.div21">+75.69%</div>
          <img :class="$style.clientDashboardDarkUpArrowIcon" alt="" />
        </div>
      </div>
      <div :class="$style.div22">
        <div :class="$style.base" />
        <div :class="$style.btcIdr">
          <b :class="$style.btc">BTC</b>
          <b :class="$style.idr">IDR</b>
          <img :class="$style.btcIdrChild" alt="" />
        </div>
        <div :class="$style.glow" />
        <img :class="$style.path2Icon2" alt="" />
        <div :class="$style.div11">107.543,234</div>
        <div :class="$style.div24">
          <div :class="$style.div17">+132%</div>
          <img :class="$style.upArrowIcon" alt="" />
        </div>
      </div>
    </div>
    <div :class="$style.graph">
      <img :class="$style.gridBaseIcon" alt="" />
      <div :class="$style.x">
        <div :class="$style.pm">10:59PM</div>
        <div :class="$style.clientDashboardDarkPm">11:59PM</div>
        <div :class="$style.amCopy2">12:59AM</div>
        <div :class="$style.am">1:59AM</div>
        <div :class="$style.clientDashboardDarkAm">2:59AM</div>
        <div :class="$style.am2">3:59AM</div>
        <div :class="$style.am3">4:59AM</div>
        <div :class="$style.am4">5:59AM</div>
        <div :class="$style.am5">6:59AM</div>
        <div :class="$style.am6">7:59AM</div>
      </div>
      <div :class="$style.y">
        <div :class="$style.div26">2500</div>
        <div :class="$style.div27">2000</div>
        <div :class="$style.div28">3000</div>
        <div :class="$style.div29">3500</div>
        <div :class="$style.div30">4000</div>
        <div :class="$style.div31">4500</div>
        <div :class="$style.div32">5.000</div>
        <div :class="$style.div33">5.500</div>
        <div :class="$style.div34">6.000</div>
        <div :class="$style.div35">6.500</div>
      </div>
      <img :class="$style.glowEffect1" alt="" />
      <img :class="$style.path2Icon3" alt="" />
      <img :class="$style.path3Icon" alt="" />
      <div :class="$style.legends">
        <div :class="$style.group23Copy4">
          <div :class="$style.group23Copy4Child" />
          <div :class="$style.btc2">BTC</div>
          <div :class="$style.oval6" />
        </div>
      </div>
    </div>
    <div :class="$style.wallet">
      <div :class="$style.glow4" />
      <div :class="$style.wallets">Wallets</div>
      <div :class="$style.btc3">
        <img :class="$style.lineGraphIcon" alt="" />
        <div :class="$style.btc4">
          <b :class="$style.btc5">BTC</b>
          <div :class="$style.div36">1.9678</div>
        </div>
        <div :class="$style.div37">
          <div :class="$style.div38">+12,5%</div>
          <img :class="$style.combinedShapeIcon" alt="" />
        </div>
        <img :class="$style.bitcoinIcon" alt="" />
      </div>
      <div :class="$style.clientDashboardDarkEth">
        <img :class="$style.ethIcon" alt="" />
        <div :class="$style.graphLine">
          <div :class="$style.glow5" />
          <img :class="$style.graphLineIcon" alt="" />
        </div>
        <div :class="$style.eth2">
          <b :class="$style.eth3">ETH</b>
          <div :class="$style.div39">23.234</div>
        </div>
        <div :class="$style.div40">
          <div :class="$style.div13">-5.23%</div>
          <img :class="$style.downArrowIcon" alt="" />
        </div>
      </div>
      <div :class="$style.clientDashboardDarkLtc">
        <img :class="$style.litecoinIcon" alt="" />
        <img :class="$style.clientDashboardDarkGraphLineIcon" alt="" />
        <div :class="$style.div42">
          <b :class="$style.ltc2">LTC</b>
          <div :class="$style.div39">380.234</div>
        </div>
        <div :class="$style.div44">
          <div :class="$style.div45">+39.69%</div>
          <img :class="$style.combinedShapeIcon2" alt="" />
        </div>
      </div>
      <div :class="$style.addCurrency">
        <b :class="$style.clientDashboardDarkAddCurrency">+ Add Currency</b>
      </div>
    </div>
    <div :class="$style.clientDashboardDarkGraphLine">
      <div :class="$style.glow6" />
      <img :class="$style.graphLineIcon2" alt="" />
    </div>
    <div :class="$style.header">
      <div :class="$style.title">
        <b :class="$style.dashboardCopy">Dashboard</b>
        <div :class="$style.withAllOf">Welcome, User!</div>
      </div>
      <div :class="$style.faceParent">
        <img :class="$style.faceIcon" alt="" />
        <div :class="$style.name">
          <div :class="$style.pixelzWarrios">Pixelz Warrios</div>
          <img :class="$style.clientDashboardDarkDownArrowIcon" alt="" />
        </div>
      </div>
      <div :class="$style.notifBadge">
        <img :class="$style.bellIcnIcon" alt="" />
        <div :class="$style.div46">15</div>
      </div>
      <img :class="$style.magnifierIcnIcon" alt="" />
      <img :class="$style.menuIcnIcon" alt="" />
    </div>
    <div :class="$style.sidebar">
      <img :class="$style.collapseIcon" alt="" />
      <img :class="$style.activeStateMark" alt="" />
      <div :class="$style.sidebarMenu">
        <div :class="$style.menu1">
          <div :class="$style.dashboard">
            <span :class="$style.dashboar">Dashboar</span>d
          </div>
          <div :class="$style.clientDashboardDarkDashboard">
            <div :class="$style.dashboardChild" />
            <div :class="$style.rectangle4CopyParent">
              <div :class="$style.rectangle4Copy" />
              <div :class="$style.rectangle4Copy3" />
              <div :class="$style.rectangle4Copy2" />
              <div :class="$style.rectangle4Copy4" />
            </div>
          </div>
        </div>
        <div :class="$style.menu2">
          <div :class="$style.clientDashboardDarkWallet">Wallet</div>
          <img :class="$style.walletIcon" alt="" />
        </div>
        <div :class="$style.menu3">
          <div :class="$style.messages">
            <span :class="$style.dashboar">Message</span>s
          </div>
          <div :class="$style.notifeMark" />
          <img :class="$style.messageIcon" alt="" />
        </div>
        <div :class="$style.menu4">
          <div :class="$style.trade">
            <span :class="$style.dashboar">Trad</span>e
          </div>
          <img :class="$style.tradeIcon" alt="" />
        </div>
        <div :class="$style.menu5">
          <div :class="$style.trade">
            <span :class="$style.dashboar">Account</span> Setting
          </div>
          <img :class="$style.accountIcon" alt="" />
        </div>
      </div>
    </div>
    <div :class="$style.notifications">
      <div :class="$style.base4" />
      <div :class="$style.avatarParent">
        <img :class="$style.avatarIcon" alt="" />
        <b :class="$style.dannyJacobs">Danny Jacobs</b>
        <div :class="$style.besokJanganLupa">Let’s talk when we have time.</div>
        <div :class="$style.sentYouA">Sent you a message</div>
        <div :class="$style.hoursAgo">2 hours ago</div>
      </div>
      <div :class="$style.avatarGroup">
        <img :class="$style.clientDashboardDarkAvatarIcon" alt="" />
        <div :class="$style.besokJanganLupa">Hello!</div>
        <b :class="$style.cliffordHale">Clifford Hale</b>
        <div :class="$style.clientDashboardDarkSentYouA">Sent you a message</div>
        <div :class="$style.hoursAgo">2 hours ago</div>
      </div>
      <div :class="$style.hoveredStateParent">
        <div :class="$style.hoveredState" />
        <div :class="$style.group30Copy">
          <div :class="$style.avatar">
            <div :class="$style.base5" />
            <b :class="$style.l">L</b>
          </div>
          <div :class="$style.broIkiNggo">Here’s some money for you!</div>
          <div :class="$style.openMyWallet">Open my wallet</div>
          <b :class="$style.lottieMarsh">Lottie Marsh</b>
          <div :class="$style.sentYouA2">Sent you a coin</div>
          <div :class="$style.ltcParent">
            <b :class="$style.ltc3">LTC</b>
            <div :class="$style.div47">+380.234</div>
          </div>
          <div :class="$style.hoursAgo2">3 hours ago</div>
        </div>
        <img :class="$style.combinedShapeIcon3" alt="" />
      </div>
      <div :class="$style.avatarContainer">
        <div :class="$style.clientDashboardDarkAvatar">
          <div :class="$style.base6" />
          <b :class="$style.b">B</b>
        </div>
        <div :class="$style.bitcoinBaruSaja">Bitcoin is up by 5 points today.</div>
        <div :class="$style.tradeNow">Trade now</div>
        <b :class="$style.btc6">BTC</b>
        <div :class="$style.news">News</div>
        <div :class="$style.oval7Parent">
          <div :class="$style.oval7" />
          <img :class="$style.path2Icon4" alt="" />
        </div>
        <div :class="$style.parent">
          <div :class="$style.div48">+39.69%</div>
          <img :class="$style.combinedShapeIcon4" alt="" />
        </div>
        <div :class="$style.hoursAgo3">3 hours ago</div>
      </div>
      <div :class="$style.clientDashboardDarkNotifications">NOTIFICATIONS</div>
      <div :class="$style.clientDashboardDarkSeeAll">See All</div>
    </div>
  </div>
</template>
<style module>
.clientDashboardDark {
  width: 100%;
  align-self: center;
  height: 1024px;
  position: relative;
  background: radial-gradient(50% 50% at 50% 50%, #000, #000);
  overflow: hidden;
  text-align: left;
  font-size: 12px;
  color: #749dc8;
  font-family: Celias;
}

.history {
  position: absolute;
  width: 29.88%;
  top: calc(50% + 230px);
  right: 1.02%;
  left: 69.1%;
  height: 250px;
  font-size: 11px;
}

.sectionTitle {
  position: absolute;
  width: 68.09%;
  top: calc(50% - 125px);
  right: 7.74%;
  left: 24.17%;
  height: 16px;
  font-size: 12px;
  color: #b1afcd;
}

.clientDashboardDarkHistory {
  position: absolute;
  top: calc(50% - 8px);
  left: 0%;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  font-weight: 500;
}

.seeAll {
  position: absolute;
  top: calc(50% - 7px);
  left: 86.01%;
  color: #749dc8;
  text-align: center;
}

.list1 {
  position: absolute;
  height: 12%;
  width: 69.95%;
  top: 20.8%;
  right: 6.58%;
  bottom: 67.2%;
  left: 23.47%;
}

.list1Child {
  position: absolute;
  height: 66.67%;
  width: 6.64%;
  top: 0%;
  right: 93.36%;
  bottom: 33.33%;
  left: 0%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: cover;
}

.akhirnyaJokoBayarContainer {
  position: absolute;
  width: 45.85%;
  top: calc(50% - 15px);
  left: 10.3%;
  font-size: 12px;
  display: inline-block;
}

.akhirnyaJokoBayar {
  letter-spacing: 0.3px;
}

.div {
  position: absolute;
  top: calc(50% - 15px);
  left: 79.4%;
  letter-spacing: 0.39px;
  text-align: center;
}

.clientDashboardDarkDiv {
  position: absolute;
  top: calc(50% - 15px);
  left: 63.79%;
  color: #00ff19;
  text-align: right;
}

.list2 {
  position: absolute;
  height: 8%;
  width: 69.95%;
  top: 40%;
  right: 6.58%;
  bottom: 52%;
  left: 23.47%;
}

.list2Child {
  position: absolute;
  height: 100%;
  width: 6.64%;
  top: 0%;
  right: 93.36%;
  bottom: 0%;
  left: 0%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
}

.cicilanMobil {
  position: absolute;
  width: 45.85%;
  top: calc(50% - 7px);
  left: 10.3%;
  font-size: 12px;
  letter-spacing: 0.3px;
  display: inline-block;
}

.div2 {
  position: absolute;
  top: calc(50% - 6px);
  left: 79.4%;
  letter-spacing: 0.39px;
  text-align: center;
}

.div3 {
  position: absolute;
  top: calc(50% - 6px);
  left: 63.79%;
  color: #a8000b;
  text-align: right;
}

.list4 {
  position: absolute;
  height: 8%;
  width: 69.95%;
  top: 76%;
  right: 6.58%;
  bottom: 16%;
  left: 23.47%;
  overflow: hidden;
}

.rectangleParent {
  position: absolute;
  height: 100%;
  width: 6.64%;
  top: 0%;
  right: 93.36%;
  bottom: 0%;
  left: 0%;
}

.groupChild {
  position: absolute;
  height: 105%;
  width: 105%;
  top: -2.5%;
  right: -2.5%;
  bottom: -2.5%;
  left: -2.5%;
  border-radius: 10px;
  border: 1px solid #0f1a27;
  box-sizing: border-box;
}

.shapeIcon {
  position: absolute;
  height: 38.5%;
  width: 35%;
  top: 30%;
  right: 30%;
  bottom: 31.5%;
  left: 35%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
}

.list5 {
  position: absolute;
  height: 8%;
  width: 69.95%;
  top: 92%;
  right: 6.58%;
  bottom: 0%;
  left: 23.47%;
  overflow: hidden;
}

.list5Child {
  position: absolute;
  height: 100%;
  width: 6.64%;
  top: 0%;
  right: 93.36%;
  bottom: 0%;
  left: 0%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: cover;
}

.div7 {
  position: absolute;
  top: calc(50% - 6px);
  left: 63.79%;
  color: #00ff19;
  text-align: right;
}

.list3Popup {
  position: absolute;
  height: 24.4%;
  width: 100%;
  top: 48.2%;
  right: 0%;
  bottom: 27.4%;
  left: 0%;
  font-size: 14px;
}

.list3PopupChild {
  position: absolute;
  height: 100%;
  width: 100%;
  top: 0%;
  right: 0%;
  bottom: 0%;
  left: 0%;
  box-shadow: 0px 46px 69px #17122b;
  backdrop-filter: blur(20.76px);
  border-radius: 10px;
  background: linear-gradient(268.95deg, rgba(0, 0, 0, 0.54), rgba(15, 26, 39, 0.87) 40.11%, rgba(0, 0, 0, 0.5));
}

.group35Copy5 {
  position: absolute;
  height: 42.62%;
  width: 90.87%;
  top: 28.69%;
  right: 4.9%;
  bottom: 28.69%;
  left: 4.23%;
  overflow: hidden;
}

.group35Copy5Child {
  position: absolute;
  height: 100%;
  width: 6.65%;
  top: 0%;
  right: 93.35%;
  bottom: 0%;
  left: 0%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
}

.buatBeliSusu {
  position: absolute;
  width: 45.88%;
  top: calc(50% - 9px);
  left: 10.31%;
  font-size: 15px;
  letter-spacing: 0.38px;
  display: inline-block;
}

.div8 {
  position: absolute;
  top: calc(50% - 8px);
  left: 79.83%;
  letter-spacing: 0.5px;
  text-align: center;
}

.div9 {
  position: absolute;
  top: calc(50% - 8px);
  left: 64.19%;
  color: #a8000b;
  text-align: right;
}

.trend {
  position: absolute;
  width: 47.29%;
  top: calc(50% + 230px);
  right: 27.43%;
  left: 25.28%;
  height: 308px;
  color: #fff;
}

.clientDashboardDarkTrend {
  position: absolute;
  top: calc(50% - 154px);
  left: 0%;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  font-weight: 500;
  color: #b1afcd;
}

.div10 {
  position: absolute;
  height: 42.53%;
  width: 30.84%;
  top: 11.69%;
  right: 69.02%;
  bottom: 45.78%;
  left: 0.15%;
}

.base {
  position: absolute;
  height: 100%;
  width: 100%;
  top: 0%;
  right: 0%;
  bottom: 0%;
  left: 0%;
  border-radius: 10px;
  opacity: 0.15;
  mix-blend-mode: normal;
}

.btcUsd {
  position: absolute;
  width: 43.81%;
  top: calc(50% - 50.5px);
  right: 47.62%;
  left: 8.57%;
  height: 16px;
  text-align: right;
}

.btc {
  position: absolute;
  top: calc(50% - 8px);
  left: 0%;
  opacity: 0.2;
  mix-blend-mode: normal;
}

.usd {
  position: absolute;
  top: calc(50% - 8px);
  left: 70.65%;
  opacity: 0.2;
  mix-blend-mode: normal;
}

.icnIcon {
  position: absolute;
  height: 62.5%;
  width: 9.78%;
  top: 18.75%;
  right: 44.57%;
  bottom: 18.75%;
  left: 45.65%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
}

.glow {
  position: absolute;
  height: 15.27%;
  width: 8.86%;
  top: 42.75%;
  right: 6.05%;
  bottom: 41.98%;
  left: 85.09%;
  filter: blur(41.12px);
  border-radius: 50%;
  background: linear-gradient(49.24deg, rgba(168, 0, 11, 0), #a8000b);
  transform: rotate(29deg);
  transform-origin: 0 0;
}

.div11 {
  position: absolute;
  top: calc(50% - 22.5px);
  left: 10%;
  font-size: 17px;
  opacity: 0.7;
  mix-blend-mode: normal;
}

.div12 {
  position: absolute;
  width: 22.86%;
  top: calc(50% - 48.5px);
  right: 8.1%;
  left: 69.05%;
  height: 14px;
  font-size: 11px;
  color: #a8000b;
}

.div13 {
  position: absolute;
  top: calc(50% - 7px);
  left: 27.08%;
}

.downArrowIcon {
  position: absolute;
  height: 42.86%;
  width: 12.5%;
  top: 21.43%;
  right: 87.5%;
  bottom: 35.71%;
  left: 0%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
}

.div14 {
  position: absolute;
  height: 42.53%;
  width: 30.84%;
  top: 11.69%;
  right: 34.51%;
  bottom: 45.78%;
  left: 34.65%;
}

.ethUsd {
  position: absolute;
  width: 43.33%;
  top: calc(50% - 50.5px);
  right: 47.14%;
  left: 9.52%;
  height: 16px;
  text-align: right;
}

.clientDashboardDarkUsd {
  position: absolute;
  top: calc(50% - 8px);
  left: 70.33%;
  text-align: left;
  opacity: 0.2;
  mix-blend-mode: normal;
}

.clientDashboardDarkIcnIcon {
  position: absolute;
  height: 62.5%;
  width: 9.89%;
  top: 18.75%;
  right: 46.15%;
  bottom: 18.75%;
  left: 43.96%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
}

.clientDashboardDarkGlow {
  position: absolute;
  height: 15.27%;
  width: 8.86%;
  top: 42.75%;
  right: 6.05%;
  bottom: 41.98%;
  left: 85.09%;
  filter: blur(41.12px);
  border-radius: 50%;
  background: linear-gradient(49.24deg, rgba(110, 255, 97, 0), #5aff5c);
  transform: rotate(29deg);
  transform-origin: 0 0;
}

.path2Icon {
  position: absolute;
  height: 26.18%;
  width: 76.67%;
  top: 50.94%;
  right: 13.33%;
  bottom: 22.87%;
  left: 10%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: contain;
}

.div16 {
  position: absolute;
  width: 20%;
  top: calc(50% - 48.5px);
  right: 13.81%;
  left: 66.19%;
  height: 14px;
  font-size: 11px;
  color: #0074cc;
}

.div17 {
  position: absolute;
  top: calc(50% - 7px);
  left: 23.81%;
}

.upArrowIcon {
  position: absolute;
  height: 42.86%;
  width: 11.9%;
  top: 21.43%;
  right: 88.1%;
  bottom: 35.71%;
  left: 0%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
}

.div18 {
  position: absolute;
  height: 42.53%;
  width: 30.84%;
  top: 11.69%;
  right: 0%;
  bottom: 45.78%;
  left: 69.16%;
}

.clientDashboardDarkEthUsd {
  position: absolute;
  width: 42.86%;
  top: calc(50% - 50.5px);
  right: 47.14%;
  left: 10%;
  height: 16px;
  text-align: right;
}

.usd2 {
  position: absolute;
  top: calc(50% - 8px);
  left: 70%;
  text-align: left;
  opacity: 0.2;
  mix-blend-mode: normal;
}

.icnIcon2 {
  position: absolute;
  height: 62.5%;
  width: 10%;
  top: 18.75%;
  right: 46.67%;
  bottom: 18.75%;
  left: 43.33%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
}

.glow2 {
  position: absolute;
  height: 15.27%;
  width: 11%;
  top: 48.79%;
  right: 8.17%;
  bottom: 35.94%;
  left: 80.83%;
  filter: blur(41.12px);
  border-radius: 50%;
  background: linear-gradient(49.24deg, rgba(255, 189, 61, 0), #ffce5a);
  transform: rotate(29deg);
  transform-origin: 0 0;
}

.clientDashboardDarkPath2Icon {
  position: absolute;
  height: 17.56%;
  width: 73.33%;
  top: 59.54%;
  right: 16.67%;
  bottom: 22.9%;
  left: 10%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: contain;
}

.div20 {
  position: absolute;
  width: 25.24%;
  top: calc(50% - 48.5px);
  right: 8.57%;
  left: 66.19%;
  height: 14px;
  font-size: 11px;
  color: #0074cc;
}

.div21 {
  position: absolute;
  top: calc(50% - 7px);
  left: 18.87%;
}

.clientDashboardDarkUpArrowIcon {
  position: absolute;
  height: 42.86%;
  width: 9.43%;
  top: 21.43%;
  right: 90.57%;
  bottom: 35.71%;
  left: 0%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
}

.div22 {
  position: absolute;
  height: 42.53%;
  width: 30.84%;
  top: 57.47%;
  right: 69.02%;
  bottom: 0%;
  left: 0.15%;
}

.btcIdr {
  position: absolute;
  width: 41.9%;
  top: calc(50% - 50.5px);
  right: 49.52%;
  left: 8.57%;
  height: 16px;
  text-align: right;
}

.idr {
  position: absolute;
  top: calc(50% - 8px);
  left: 75%;
  text-align: left;
  opacity: 0.2;
  mix-blend-mode: normal;
}

.btcIdrChild {
  position: absolute;
  height: 62.5%;
  width: 10.23%;
  top: 18.75%;
  right: 42.05%;
  bottom: 18.75%;
  left: 47.73%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
}

.path2Icon2 {
  position: absolute;
  height: 26.72%;
  width: 78.24%;
  top: 52.67%;
  right: 10.93%;
  bottom: 20.61%;
  left: 10.83%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
}

.div24 {
  position: absolute;
  width: 20%;
  top: calc(50% - 48.5px);
  right: 9.05%;
  left: 70.95%;
  height: 14px;
  font-size: 11px;
  color: #0074cc;
}

.graph {
  position: absolute;
  top: 273px;
  left: 362px;
  width: 950px;
  height: 421px;
  text-align: right;
}

.gridBaseIcon {
  position: absolute;
  top: 0px;
  left: 50px;
  width: 890px;
  height: 390px;
}

.x {
  position: absolute;
  width: 90.26%;
  top: calc(50% + 195.5px);
  right: 2.89%;
  left: 6.84%;
  height: 15px;
  text-align: center;
}

.pm {
  position: absolute;
  top: calc(50% - 7.5px);
  left: 0%;
  letter-spacing: 0.43px;
}

.clientDashboardDarkPm {
  position: absolute;
  top: calc(50% - 7.5px);
  left: 10.61%;
  letter-spacing: 0.43px;
}

.amCopy2 {
  position: absolute;
  top: calc(50% - 7.5px);
  left: 20.99%;
  letter-spacing: 0.43px;
}

.am {
  position: absolute;
  top: calc(50% - 7.5px);
  left: 31.78%;
  letter-spacing: 0.43px;
}

.clientDashboardDarkAm {
  position: absolute;
  top: calc(50% - 7.5px);
  left: 42.16%;
  letter-spacing: 0.43px;
}

.am2 {
  position: absolute;
  top: calc(50% - 7.5px);
  left: 52.65%;
  letter-spacing: 0.43px;
}

.am3 {
  position: absolute;
  top: calc(50% - 7.5px);
  left: 63.15%;
  letter-spacing: 0.43px;
}

.am4 {
  position: absolute;
  top: calc(50% - 7.5px);
  left: 73.64%;
  letter-spacing: 0.43px;
}

.am5 {
  position: absolute;
  top: calc(50% - 7.5px);
  left: 84.14%;
  letter-spacing: 0.43px;
}

.am6 {
  position: absolute;
  top: calc(50% - 7.5px);
  left: 94.64%;
  letter-spacing: 0.43px;
}

.y {
  position: absolute;
  width: 3.68%;
  top: calc(50% - 201.5px);
  right: 96.32%;
  left: 0%;
  height: 375px;
}

.div26 {
  position: absolute;
  top: calc(50% + 132.5px);
  left: 14.29%;
  letter-spacing: 0.43px;
}

.div27 {
  position: absolute;
  top: calc(50% + 172.5px);
  left: 11.43%;
  letter-spacing: 0.43px;
}

.div28 {
  position: absolute;
  top: calc(50% + 92.5px);
  left: 8.57%;
  letter-spacing: 0.43px;
}

.div29 {
  position: absolute;
  top: calc(50% + 52.5px);
  left: 11.43%;
  letter-spacing: 0.43px;
}

.div30 {
  position: absolute;
  top: calc(50% + 12.5px);
  left: 8.57%;
  letter-spacing: 0.43px;
}

.div31 {
  position: absolute;
  top: calc(50% - 27.5px);
  left: 11.43%;
  letter-spacing: 0.43px;
}

.div32 {
  position: absolute;
  top: calc(50% - 67.5px);
  left: 0%;
  letter-spacing: 0.43px;
}

.div33 {
  position: absolute;
  top: calc(50% - 107.5px);
  left: 2.86%;
  letter-spacing: 0.43px;
}

.div34 {
  position: absolute;
  top: calc(50% - 147.5px);
  left: 0%;
  letter-spacing: 0.43px;
}

.div35 {
  position: absolute;
  top: calc(50% - 187.5px);
  left: 2.86%;
  letter-spacing: 0.43px;
}

.glowEffect1 {
  position: absolute;
  top: 54.89px;
  left: 412px;
  width: 423.4px;
  height: 208.1px;
  opacity: 0.45;
  mix-blend-mode: normal;
}

.path2Icon3 {
  position: absolute;
  top: 143px;
  left: 54px;
  width: 813px;
  height: 157px;
}

.path3Icon {
  position: absolute;
  top: 104.03px;
  left: 51px;
  width: 899px;
  height: 206px;
}

.legends {
  position: absolute;
  top: 2px;
  left: 60px;
  width: 74px;
  height: 28px;
}

.group23Copy4 {
  position: absolute;
  top: 0px;
  left: 0px;
  width: 74px;
  height: 28px;
  overflow: hidden;
}

.group23Copy4Child {
  position: absolute;
  height: 100%;
  width: 100%;
  top: 0%;
  right: 0%;
  bottom: 0%;
  left: 0%;
  backdrop-filter: blur(18.55px);
  border-radius: 14.5px;
  background-color: rgba(0, 0, 0, 0);
}

.btc2 {
  position: absolute;
  top: calc(50% - 8px);
  left: 41.89%;
  letter-spacing: 0.43px;
  font-weight: 500;
}

.oval6 {
  position: absolute;
  height: 28.57%;
  width: 10.81%;
  top: 35.71%;
  right: 68.92%;
  bottom: 35.71%;
  left: 20.27%;
  border-radius: 50%;
  background-color: #00ff19;
}

.wallet {
  position: absolute;
  height: 11.33%;
  width: 57.78%;
  top: 12.01%;
  right: 17.78%;
  bottom: 76.66%;
  left: 24.44%;
  text-align: right;
  color: #fff;
}

.glow4 {
  position: absolute;
  height: 59.48%;
  width: 21.15%;
  top: 40.52%;
  right: 78.85%;
  bottom: 0%;
  left: 0%;
  filter: blur(90.88px);
  border-radius: 5px;
  background: linear-gradient(113.91deg, #0074cc, rgba(0, 116, 204, 0));
  opacity: 0.5;
  mix-blend-mode: normal;
}

.wallets {
  position: absolute;
  top: calc(50% - 58px);
  left: 1.44%;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  font-weight: 500;
  color: #b1afcd;
  text-align: left;
}

.btc3 {
  position: absolute;
  top: 36px;
  left: 12px;
  border-radius: 10px;
  background-color: #0074cc;
  width: 190px;
  height: 74px;
  overflow: hidden;
}

.lineGraphIcon {
  position: absolute;
  height: 12.97%;
  width: 16.84%;
  top: 61.85%;
  right: 51.05%;
  bottom: 25.18%;
  left: 32.11%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
}

.btc4 {
  position: absolute;
  width: 46.32%;
  top: calc(50% - 24px);
  right: 13.16%;
  left: 40.53%;
  height: 22px;
}

.btc5 {
  position: absolute;
  top: calc(50% - 6px);
  left: 69.32%;
  opacity: 0.5;
  mix-blend-mode: normal;
}

.div36 {
  position: absolute;
  top: calc(50% - 11px);
  left: 0%;
  font-size: 17px;
  font-weight: 500;
}

.div37 {
  position: absolute;
  width: 24.74%;
  top: calc(50% + 7px);
  right: 16.32%;
  left: 58.95%;
  height: 14px;
  text-align: left;
  font-size: 11px;
}

.div38 {
  position: absolute;
  top: calc(50% - 7px);
  left: 27.66%;
}

.combinedShapeIcon {
  position: absolute;
  height: 42.86%;
  width: 12.77%;
  top: 21.43%;
  right: 87.23%;
  bottom: 35.71%;
  left: 0%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
}

.bitcoinIcon {
  position: relative;
  width: 13.6px;
  height: 18px;
}

.clientDashboardDarkEth {
  position: absolute;
  top: 36px;
  left: 222px;
  border-radius: 10px;
  border: 1px solid #0f1a27;
  box-sizing: border-box;
  width: 190px;
  height: 74px;
  mix-blend-mode: normal;
}

.ethIcon {
  position: absolute;
  height: 35.14%;
  width: 8.95%;
  top: 31.08%;
  right: 80%;
  bottom: 33.78%;
  left: 11.05%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
}

.graphLine {
  position: absolute;
  height: 20.54%;
  width: 20.95%;
  top: 64.86%;
  right: 40.11%;
  bottom: 14.59%;
  left: 38.95%;
}

.glow5 {
  position: absolute;
  height: 44.74%;
  width: 39.45%;
  top: 10.75%;
  right: -5.01%;
  bottom: 44.51%;
  left: 65.56%;
  filter: blur(18.88px);
  border-radius: 50%;
  background: linear-gradient(49.24deg, rgba(168, 0, 11, 0), #a8000b);
  transform: rotate(29deg);
  transform-origin: 0 0;
}

.graphLineIcon {
  position: absolute;
  height: 60.53%;
  width: 77.89%;
  top: 0%;
  right: 22.11%;
  bottom: 39.47%;
  left: 0%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: contain;
}

.eth2 {
  position: absolute;
  width: 46.32%;
  top: calc(50% - 23px);
  right: 16.32%;
  left: 37.37%;
  height: 22px;
}

.eth3 {
  position: absolute;
  top: calc(50% - 7px);
  left: 71.59%;
  opacity: 0.2;
  mix-blend-mode: normal;
}

.div39 {
  position: absolute;
  top: calc(50% - 11px);
  left: 0%;
  font-size: 17px;
  opacity: 0.7;
  mix-blend-mode: normal;
}

.div40 {
  position: absolute;
  width: 25.26%;
  top: calc(50% + 7px);
  right: 14.21%;
  left: 60.53%;
  height: 14px;
  text-align: left;
  font-size: 11px;
  color: #a8000b;
}

.clientDashboardDarkLtc {
  position: absolute;
  top: 36px;
  left: 432px;
  border-radius: 10px;
  border: 1px solid #0f1a27;
  box-sizing: border-box;
  width: 190px;
  height: 74px;
  mix-blend-mode: normal;
}

.litecoinIcon {
  position: absolute;
  height: 32.3%;
  width: 12.58%;
  top: 33.87%;
  right: 76.34%;
  bottom: 33.83%;
  left: 11.08%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
}

.clientDashboardDarkGraphLineIcon {
  position: absolute;
  height: 20.27%;
  width: 19.26%;
  top: 54.61%;
  right: 46.53%;
  bottom: 25.12%;
  left: 34.21%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
}

.div42 {
  position: absolute;
  width: 52.63%;
  top: calc(50% - 23px);
  right: 13.16%;
  left: 34.21%;
  height: 22px;
}

.ltc2 {
  position: absolute;
  top: calc(50% - 7px);
  left: 76%;
  opacity: 0.2;
  mix-blend-mode: normal;
}

.div44 {
  position: absolute;
  width: 29.47%;
  top: calc(50% + 7px);
  right: 14.21%;
  left: 56.32%;
  height: 14px;
  text-align: left;
  font-size: 11px;
  color: #00ff19;
}

.div45 {
  position: absolute;
  top: calc(50% - 7px);
  left: 21.43%;
}

.combinedShapeIcon2 {
  position: absolute;
  height: 42.86%;
  width: 10.71%;
  top: 21.43%;
  right: 89.29%;
  bottom: 35.71%;
  left: 0%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
}

.addCurrency {
  position: absolute;
  height: 63.79%;
  width: 22.84%;
  top: 31.03%;
  right: 0%;
  bottom: 5.17%;
  left: 77.16%;
  border-radius: 10px;
  border: 1px dashed #0f1a27;
  box-sizing: border-box;
  mix-blend-mode: normal;
  font-size: 13px;
}

.clientDashboardDarkAddCurrency {
  position: absolute;
  top: calc(50% - 8px);
  left: 23.16%;
  opacity: 0.2;
  mix-blend-mode: normal;
}

.clientDashboardDarkGraphLine {
  position: absolute;
  height: 3.35%;
  width: 11.18%;
  top: 85.64%;
  right: 61.53%;
  bottom: 11.01%;
  left: 27.29%;
}

.glow6 {
  position: absolute;
  height: 55.1%;
  width: 36.09%;
  top: 10.73%;
  right: -1.61%;
  bottom: 34.17%;
  left: 65.52%;
  filter: blur(18.88px);
  border-radius: 50%;
  background: linear-gradient(49.24deg, rgba(168, 0, 11, 0), #a8000b);
  transform: rotate(17.2deg);
  transform-origin: 0 0;
}

.graphLineIcon2 {
  position: absolute;
  height: 60.35%;
  width: 77.83%;
  top: 0%;
  right: 22.17%;
  bottom: 39.65%;
  left: 0%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: contain;
}

.header {
  position: absolute;
  top: 38px;
  left: 363px;
  width: 1038.4px;
  height: 58px;
  text-align: right;
  font-size: 30px;
  color: #fff;
}

.title {
  position: absolute;
  top: 0px;
  left: 0px;
  width: 353px;
  height: 58px;
  text-align: left;
}

.dashboardCopy {
  position: absolute;
  top: calc(50% - 29px);
  left: 0%;
  opacity: 0.9;
  mix-blend-mode: normal;
}

.withAllOf {
  position: absolute;
  top: calc(50% + 14px);
  left: 0.57%;
  font-size: 13px;
  color: #749dc8;
}

.faceParent {
  position: absolute;
  top: 2px;
  left: 899px;
  width: 139.4px;
  height: 28px;
  font-size: 13px;
  color: #749dc8;
}

.faceIcon {
  position: absolute;
  top: 0px;
  left: 0px;
  border-radius: 3px;
  width: 28px;
  height: 28px;
  object-fit: cover;
}

.name {
  position: absolute;
  width: 74.89%;
  top: calc(50% - 7px);
  right: 0%;
  left: 25.11%;
  height: 17px;
}

.pixelzWarrios {
  position: absolute;
  top: calc(50% - 8.5px);
  left: 0%;
  font-weight: 500;
  mix-blend-mode: normal;
}

.clientDashboardDarkDownArrowIcon {
  position: absolute;
  height: 17.65%;
  width: 5.65%;
  top: 43.8%;
  right: -0.05%;
  bottom: 38.56%;
  left: 94.4%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: contain;
}

.notifBadge {
  position: absolute;
  top: 2px;
  left: 826px;
  border-radius: 14px;
  background: linear-gradient(136.67deg, #a8000b, #a8000b);
  width: 48px;
  height: 28px;
  opacity: 0.8;
  mix-blend-mode: normal;
  font-size: 12px;
}

.bellIcnIcon {
  position: absolute;
  height: 42.86%;
  width: 20.83%;
  top: 28.57%;
  right: 60.42%;
  bottom: 28.57%;
  left: 18.75%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: cover;
}

.div46 {
  position: absolute;
  top: calc(50% - 8px);
  left: 50%;
  font-weight: 500;
}

.magnifierIcnIcon {
  position: absolute;
  top: 1px;
  left: 699px;
  width: 31px;
  height: 31px;
  mix-blend-mode: normal;
}

.menuIcnIcon {
  position: absolute;
  top: 1px;
  left: 755px;
  width: 31px;
  height: 31px;
  object-fit: contain;
  mix-blend-mode: normal;
}

.sidebar {
  position: absolute;
  top: 0px;
  left: 0px;
  background: linear-gradient(180deg, rgba(0, 0, 0, 0.65), rgba(0, 0, 0, 0.85) 57.44%, #000);
  width: 300px;
  height: 1024px;
  overflow: hidden;
  font-size: 14px;
}

.collapseIcon {
  position: absolute;
  top: 930px;
  right: 0px;
  width: 50px;
  height: 42px;
}

.activeStateMark {
  position: absolute;
  top: 236px;
  right: 284px;
  width: 34px;
  height: 34px;
}

.sidebarMenu {
  position: absolute;
  top: 239px;
  right: 39px;
  width: 201px;
  height: 306px;
}

.menu1 {
  position: absolute;
  top: 0px;
  right: 65px;
  width: 136px;
  height: 27px;
  color: #0074cc;
}

.dashboard {
  position: absolute;
  top: 5px;
  right: 0px;
  font-weight: 500;
}

.dashboar {
  letter-spacing: 0.5px;
}

.clientDashboardDarkDashboard {
  position: absolute;
  top: 0px;
  right: 109px;
  width: 27px;
  height: 27px;
}

.dashboardChild {
  position: absolute;
  top: 0px;
  right: 0px;
  width: 27px;
  height: 27px;
}

.rectangle4CopyParent {
  position: absolute;
  top: 7.1px;
  right: 6.89px;
  width: 13px;
  height: 13px;
}

.rectangle4Copy {
  position: absolute;
  top: 0px;
  right: 9px;
  border-radius: 1.4px;
  background-color: #0074cc;
  width: 4px;
  height: 4px;
}

.rectangle4Copy3 {
  position: absolute;
  top: 6px;
  right: 9px;
  border-radius: 1.4px;
  background-color: #0074cc;
  width: 4px;
  height: 4px;
}

.rectangle4Copy2 {
  position: absolute;
  top: 0px;
  right: 3px;
  border-radius: 1.4px;
  background-color: #0074cc;
  width: 4px;
  height: 4px;
}

.rectangle4Copy4 {
  position: absolute;
  top: 6px;
  right: 0px;
  border-radius: 1.4px;
  background-color: #0074cc;
  width: 7px;
  height: 7px;
}

.menu2 {
  position: absolute;
  top: 64px;
  right: 100px;
  width: 101px;
  height: 27px;
}

.clientDashboardDarkWallet {
  position: absolute;
  top: 5px;
  right: 0px;
  letter-spacing: 0.5px;
}

.walletIcon {
  position: absolute;
  top: 0px;
  right: 74px;
  width: 27px;
  height: 27px;
  object-fit: cover;
}

.menu3 {
  position: absolute;
  top: 143px;
  right: 0px;
  width: 201px;
  height: 27px;
}

.messages {
  position: absolute;
  top: 5px;
  right: 74px;
}

.notifeMark {
  position: absolute;
  top: 11px;
  right: 0px;
  box-shadow: 0px 0px 5px #e01066;
  border-radius: 50%;
  background: linear-gradient(180deg, #a8000b);
  width: 6px;
  height: 6px;
  opacity: 0.8;
  mix-blend-mode: normal;
}

.messageIcon {
  position: absolute;
  top: 0px;
  right: 174px;
  width: 27px;
  height: 27px;
  object-fit: cover;
}

.menu4 {
  position: absolute;
  top: 210px;
  right: 105px;
  width: 96px;
  height: 27px;
}

.trade {
  position: absolute;
  top: 5px;
  right: 0px;
}

.tradeIcon {
  position: absolute;
  top: 0px;
  right: 69px;
  width: 27px;
  height: 27px;
  object-fit: cover;
}

.menu5 {
  position: absolute;
  top: 279px;
  right: 34px;
  width: 167px;
  height: 27px;
}

.accountIcon {
  position: absolute;
  top: 0px;
  right: 140px;
  width: 27px;
  height: 27px;
}

.notifications {
  position: absolute;
  top: 94px;
  left: 996px;
  width: 413px;
  height: 530px;
}

.base4 {
  position: absolute;
  height: 100%;
  width: 100%;
  top: 0%;
  right: 0%;
  bottom: 0%;
  left: 0%;
  box-shadow: 0px 48px 69px rgba(23, 18, 43, 0.85);
  backdrop-filter: blur(20px);
  border-radius: 10px;
  background: linear-gradient(210.96deg, rgba(0, 0, 0, 0.61), rgba(0, 0, 0, 0.7) 40.11%, rgba(0, 0, 0, 0));
}

.avatarParent {
  position: absolute;
  height: 11.89%;
  width: 84.26%;
  top: 75.47%;
  right: 9.69%;
  bottom: 12.64%;
  left: 6.05%;
  font-size: 11px;
}

.avatarIcon {
  position: absolute;
  height: 60.32%;
  width: 10.92%;
  top: 0%;
  right: 89.08%;
  bottom: 39.68%;
  left: 0%;
  border-radius: 50%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: cover;
}

.dannyJacobs {
  position: absolute;
  top: calc(50% - 30.5px);
  left: 15.23%;
  font-size: 14px;
  color: #b1afcd;
  mix-blend-mode: normal;
}

.besokJanganLupa {
  position: absolute;
  width: 84.77%;
  top: calc(50% - 6.5px);
  left: 15.23%;
  font-size: 12px;
  display: inline-block;
}

.sentYouA {
  position: absolute;
  top: calc(50% - 28.5px);
  left: 45.4%;
  letter-spacing: -0.18px;
  mix-blend-mode: normal;
}

.hoursAgo {
  position: absolute;
  top: calc(50% + 17.5px);
  left: 15.8%;
  mix-blend-mode: normal;
}

.avatarGroup {
  position: absolute;
  height: 11.89%;
  width: 84.26%;
  top: 13.58%;
  right: 9.69%;
  bottom: 74.53%;
  left: 6.05%;
  font-size: 11px;
}

.clientDashboardDarkAvatarIcon {
  position: absolute;
  height: 60.32%;
  width: 10.92%;
  top: 0%;
  right: 89.08%;
  bottom: 39.68%;
  left: 0%;
  border-radius: 50%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  object-fit: cover;
  opacity: 0.5;
  mix-blend-mode: normal;
}

.cliffordHale {
  position: absolute;
  top: calc(50% - 30.5px);
  left: 15.23%;
  font-size: 14px;
  opacity: 0.7;
  mix-blend-mode: normal;
}

.clientDashboardDarkSentYouA {
  position: absolute;
  top: calc(50% - 27.5px);
  left: 43.39%;
  letter-spacing: -0.18px;
  opacity: 0.7;
  mix-blend-mode: normal;
}

.hoveredStateParent {
  position: absolute;
  height: 20.38%;
  width: 100%;
  top: 28.87%;
  right: 0%;
  bottom: 50.75%;
  left: 0%;
}

.hoveredState {
  position: absolute;
  height: 100%;
  width: 100%;
  top: 0%;
  right: 0%;
  bottom: 0%;
  left: 0%;
  background: linear-gradient(224.09deg, rgba(15, 26, 39, 0.45), rgba(15, 26, 39, 0.49));
}

.group30Copy {
  position: absolute;
  height: 80.56%;
  width: 87.89%;
  top: 10.19%;
  right: 6.05%;
  bottom: 9.26%;
  left: 6.05%;
}

.avatar {
  position: absolute;
  height: 43.68%;
  width: 10.47%;
  top: 1.15%;
  right: 89.53%;
  bottom: 55.17%;
  left: 0%;
  text-align: center;
  font-size: 15px;
  color: #fff;
}

.base5 {
  position: absolute;
  height: 100%;
  width: 100%;
  top: 0%;
  right: 0%;
  bottom: 0%;
  left: 0%;
  border-radius: 50%;
  background: linear-gradient(213.66deg, #00ff19, #23e73c);
}

.l {
  position: absolute;
  top: calc(50% - 10px);
  left: 39.47%;
}

.broIkiNggo {
  position: absolute;
  width: 81.27%;
  top: calc(50% - 19.5px);
  left: 14.33%;
  display: inline-block;
}

.openMyWallet {
  position: absolute;
  top: calc(50% + 5.5px);
  left: 66.39%;
  text-decoration: underline;
  color: #0074cc;
  text-align: right;
}

.lottieMarsh {
  position: absolute;
  top: calc(50% - 43.5px);
  left: 14.6%;
  font-size: 14px;
  color: #b1afcd;
  mix-blend-mode: normal;
}

.sentYouA2 {
  position: absolute;
  top: calc(50% - 41.5px);
  left: 40.77%;
  font-size: 11px;
  letter-spacing: -0.18px;
  mix-blend-mode: normal;
}

.ltcParent {
  position: absolute;
  height: 18.39%;
  width: 24.24%;
  top: 55.17%;
  right: 61.16%;
  bottom: 26.44%;
  left: 14.6%;
  overflow: hidden;
  color: #fff;
}

.ltc3 {
  position: absolute;
  top: calc(50% - 7px);
  left: 73.86%;
  opacity: 0.2;
  mix-blend-mode: normal;
}

.div47 {
  position: absolute;
  top: calc(50% - 8px);
  left: 0%;
  font-size: 13px;
  font-weight: 500;
  color: #00ff19;
}

.hoursAgo2 {
  position: absolute;
  top: calc(50% + 30.5px);
  left: 15.15%;
  font-size: 11px;
  mix-blend-mode: normal;
}

.combinedShapeIcon3 {
  position: relative;
  width: 4px;
  height: 18px;
  object-fit: contain;
}

.avatarContainer {
  position: absolute;
  height: 16.98%;
  width: 84.02%;
  top: 53.02%;
  right: 9.93%;
  bottom: 30%;
  left: 6.05%;
}

.clientDashboardDarkAvatar {
  position: absolute;
  height: 42.22%;
  width: 10.95%;
  top: 1.11%;
  right: 89.05%;
  bottom: 56.67%;
  left: 0%;
  text-align: center;
  font-size: 15px;
  color: #fff;
}

.base6 {
  position: absolute;
  height: 100%;
  width: 100%;
  top: 0%;
  right: 0%;
  bottom: 0%;
  left: 0%;
  border-radius: 50%;
  background: linear-gradient(136.67deg, #ff409a, #c438ef);
  opacity: 0.8;
  mix-blend-mode: normal;
}

.b {
  position: absolute;
  top: calc(50% - 9px);
  left: 36.84%;
}

.bitcoinBaruSaja {
  position: absolute;
  width: 85.01%;
  top: calc(50% - 21px);
  left: 14.99%;
  display: inline-block;
}

.tradeNow {
  position: absolute;
  top: calc(50% + 5px);
  left: 78.1%;
  color: #0074cc;
  text-align: right;
}

.btc6 {
  position: absolute;
  top: calc(50% - 45px);
  left: 15.27%;
  font-size: 14px;
  color: #b1afcd;
  mix-blend-mode: normal;
}

.news {
  position: absolute;
  top: calc(50% - 43px);
  left: 26.51%;
  font-size: 11px;
  letter-spacing: -0.18px;
  mix-blend-mode: normal;
}

.oval7Parent {
  position: absolute;
  height: 19.78%;
  width: 12.56%;
  top: 53.34%;
  right: 72.45%;
  bottom: 26.89%;
  left: 14.99%;
}

.oval7 {
  position: absolute;
  height: 61.24%;
  width: 43.12%;
  top: 20.15%;
  right: 4.1%;
  bottom: 18.61%;
  left: 52.78%;
  filter: blur(22.65px);
  border-radius: 50%;
  background: linear-gradient(49.24deg, #339cfe);
  transform: rotate(-11deg);
  transform-origin: 0 0;
}

.path2Icon4 {
  position: absolute;
  height: 64.04%;
  width: 87.39%;
  top: 35.73%;
  right: 12.61%;
  bottom: 0.23%;
  left: 0%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
}

.parent {
  position: absolute;
  height: 17.78%;
  width: 20.17%;
  top: 54.44%;
  right: 48.41%;
  bottom: 27.78%;
  left: 31.41%;
  overflow: hidden;
  font-size: 13px;
  color: #00ff19;
}

.div48 {
  position: absolute;
  top: calc(50% - 8px);
  left: 22.86%;
  font-weight: 500;
}

.combinedShapeIcon4 {
  position: absolute;
  height: 37.5%;
  width: 8.57%;
  top: 43.75%;
  right: 91.43%;
  bottom: 18.75%;
  left: 0%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
}

.hoursAgo3 {
  position: absolute;
  top: calc(50% + 31px);
  left: 15.85%;
  font-size: 11px;
  mix-blend-mode: normal;
}

.clientDashboardDarkNotifications {
  position: absolute;
  top: calc(50% - 238px);
  left: 6.05%;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  font-weight: 500;
  color: #b1afcd;
}

.clientDashboardDarkSeeAll {
  position: absolute;
  top: calc(50% + 231px);
  left: 45.28%;
  color: #0074cc;
  text-align: center;
}
</style>